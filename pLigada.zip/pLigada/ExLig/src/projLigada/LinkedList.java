package projLigada;

public class LinkedList {
	Node header;
	Node trailer;
	int size;

	LinkedList() {
		// criar uma lista vazia
		header = null;
		trailer = null;
		size = 0;
	}

	public boolean isEmpty() {
		// verifica se a lista está vazia
		if (size == 0)
			return true;
		else
			return false;
	}
	
	public int verTamanho() {
		//retorna a qntd de elementos da lista
		return size;
	}
	
	public Node first() {
		//retorna o primeiro nó da lista
		return header;
	}
	
	public Node last() {
		//retorna o último nó da lista
		return trailer;
	}
	
	public void addFirst(Node novo) {
		//adiciona um novo nó no início da lista
		if (isEmpty()) {
			header = novo;
			trailer = novo;
		}
		else {
			novo.next = header;
			header = novo;
		}
		size++;
	}
	
	public void addLast(Node novo) {
		//adiciona um novo nó no final da lista
		if(isEmpty()) {
			header = novo;
			trailer = novo;
		}
		else {
			trailer.next = novo;
			trailer = novo;
		}
		size++;
	}
	
	public void mostraLista() {
		Node aux = header;
		aux.mostraAnimal();
		while(aux.next != null) {
			aux = aux.next;
			aux.mostraAnimal();
		}
		System.out.println("FIM DA LISTA!");
	}
}
